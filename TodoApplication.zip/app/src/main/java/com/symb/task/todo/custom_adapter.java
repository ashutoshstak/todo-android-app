package com.symb.task.todo;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class custom_adapter extends RecyclerView.Adapter<custom_adapter.myviewholder> {

    Context context;
  private   ArrayList text, datatiemstamp;
    custom_adapter(Context context, ArrayList text, ArrayList datatiemstamp){

        this.context =context;
        this.text = text;
        this.datatiemstamp = datatiemstamp;

    }


    @NonNull
    @Override
    public custom_adapter.myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);

  View view =      inflater.inflate(R.layout.layout_row,parent, false);
        return  new myviewholder(view);


    }

    @Override
    public void onBindViewHolder(@NonNull custom_adapter.myviewholder holder, int position) {
// now here we will bind the text and stuff with every view
        holder.text.setText(String.valueOf(text.get(position)));
        holder.timedate.setText(String.valueOf(datatiemstamp.get(position)));

     holder.image.setImageResource(R.drawable.calender);



    }

    @Override
    public int getItemCount() {
        return text.size();
    }
    public class myviewholder extends RecyclerView.ViewHolder {
     TextView text , timedate;
      ImageView image;


        public myviewholder(@NonNull View itemView) {
            super(itemView);
            text = itemView.findViewById(R.id.maintxt);
            timedate = itemView.findViewById(R.id.datetimetxt);
            image = itemView.findViewById(R.id.rowimg);

        }
    }
}
