package com.symb.task.todo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Button cretetask, viewtask;

        cretetask = (Button)findViewById(R.id.createbtn);
        viewtask = (Button)findViewById(R.id.listbtn);

        cretetask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(Home.this, create_todo.class);
                startActivity(in);


            }
        });

        viewtask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(Home.this, todo_list.class);
                startActivity(in);


            }
        });

    }
}