package com.symb.task.todo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class todo_list extends AppCompatActivity {

    RecyclerView recyclerView;
    Sqllitehelper mydb;
    ArrayList<String> textid, text, timestamp;
    custom_adapter custom_adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_list);

        recyclerView = (RecyclerView)findViewById(R.id.recyclerview);
     mydb = new Sqllitehelper(todo_list.this);
        text = new ArrayList<>();
        timestamp = new ArrayList<>();
        displaydata();
        custom_adapter = new custom_adapter(this,text,timestamp);
        GridLayoutManager  gridLayoutManager = new GridLayoutManager(this,2,GridLayoutManager.VERTICAL,false);
       recyclerView.setLayoutManager(gridLayoutManager);
       recyclerView.setAdapter(custom_adapter);



    }

    void displaydata(){
        // we have to make an cursor object over here
        Cursor cursor = mydb.readalldata();
        // here we have made an cursor object and we are reading adn

        if(cursor.getCount() == 0){

            Toast.makeText(todo_list.this, " No data exist", Toast.LENGTH_SHORT).show();
        }

        else
        {

            while(cursor.moveToNext()){

                text.add(cursor.getString(1));
                timestamp.add(cursor.getString(2));

            }
        }
    }

}