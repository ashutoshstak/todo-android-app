package com.symb.task.todo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class create_todo extends AppCompatActivity {
EditText text;
Button savebtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_todo);

        text = (EditText)findViewById(R.id.tasktxt);
        savebtn = (Button)findViewById(R.id.btnsave);

        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Sqllitehelper sql = new Sqllitehelper(create_todo.this);

                Calendar c = Calendar.getInstance();

              //  System.out.println("Current time => " + c.getTime());

                //SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                //String formattedDate = df.format(c.getTime());

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                String currentDateandTime = sdf.format(new Date());
                sql.addtext(text.getText().toString().trim(),currentDateandTime);
            }
        });

    }
}