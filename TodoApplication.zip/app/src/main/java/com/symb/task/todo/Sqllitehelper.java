package com.symb.task.todo;

import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Sqllitehelper extends SQLiteOpenHelper {

   private Context context;
   private static final String DATABASE_NAME = "todo.db";
   public static final int DATABSE_VERSION = 1;
   public static final String TABLE_NAME ="todo";
   public static final String COLOUM_ID = "_id";
   public static final String COLOUM_TEXT = "TEXT";
   public static final String COLUM_TIME_STAMP = "time";


    public Sqllitehelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABSE_VERSION );
       this.context = context;



    }

    @Override
    public void onCreate(SQLiteDatabase db) {

       String query = "CREATE TABLE " + TABLE_NAME +
                " (" + COLOUM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
               COLOUM_TEXT + " TEXT, " +
               COLUM_TIME_STAMP + " INTEGER);";

           db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db); // when ever we provide upgrade to the table
        // we will use the oncreate method

    }

    void addtext(String text, String timestamp){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(COLOUM_TEXT, text);
        contentValues.put(COLUM_TIME_STAMP, timestamp);


      long result =   db.insert(TABLE_NAME,null, contentValues);

      if (result == -1){
          Toast.makeText(context,"Can not write in database",Toast.LENGTH_SHORT).show();


      }
      else
      {
          Toast.makeText(context,"Success",Toast.LENGTH_SHORT).show();

      }


    }

    Cursor readalldata(){

        String query = "SELECT * FROM " + TABLE_NAME;

   Cursor cursor = null;
     SQLiteDatabase db = this.getReadableDatabase();

        if(db != null){
          cursor =  db.rawQuery(query,null);
        }
return  cursor;
    }
}

